import React from 'react';
import '../../styles/styles.css';

function Footer() {
  return (
    <footer>
      <p>Joaquin Becerra - Bautista Pigni</p>
    </footer>
  );
}

export default Footer;